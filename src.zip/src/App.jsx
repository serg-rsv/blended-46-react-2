import { Component } from 'react';
import { Button } from './Button/Button';
import { getMovies } from './services/api';
import { mapperFilms } from './utils/mapper';
import { MoviesGallery } from './MoviesGallery/MoviesGallery';

export class App extends Component {
  state = {
    movies: [],
    page: 1,
    isLoading: false,
  };

  fetchMovies = () => {
    const { page } = this.state;
    this.setState({ isLoading: true });

    getMovies(page)
      .then(({ data }) => this.setState({ movies: mapperFilms(data.results) }))
      .catch(console.log)
      .finally(this.setState({ isLoading: false }));
  };

  render() {
    const { movies } = this.state;
    return (
      <>
        {movies.length === 0 && (
          <Button text="Show films list" handleClick={this.fetchMovies} />
        )}
        <MoviesGallery movies={movies} />
      </>
    );
  }
}

export default App;
