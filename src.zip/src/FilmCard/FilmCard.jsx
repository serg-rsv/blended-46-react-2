export const FilmCard = ({ movie: { votes, title, poster, watched } }) => {
  return (
    <li>
      <h2>{title}</h2>
      <p>Votes: {votes}</p>
      <p>Watched: {watched.toString()}</p>
    </li>
  );
};
