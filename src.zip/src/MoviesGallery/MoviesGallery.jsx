import { nanoid } from 'nanoid';
import { FilmCard } from '../FilmCard/FilmCard';

export const MoviesGallery = ({ movies }) => {
  return movies.map(({ id, ...restProps }) => (
    <FilmCard key={id + nanoid()} movie={restProps} />
  ));
};
